H.A.S Green Wood Sawmill - Website package
-----------------------------------------
Files in this package:
- index.html        : main website page
- style.css         : styling
- coin.js           : Three.js script that creates a realistic coin-toss animation using logo.png
- logo.png          : (NOT included) Place your logo image here (preferably square 1024x1024). It must be named 'logo.png'.
- SPI_Interface_Project_Presentation.pptx : OPTIONAL - put your PPT here to enable download link on the page.

How to use:
1. Download this folder and extract it.
2. Add your logo image to the folder named exactly: logo.png
3. (Optional) Add your PPT file named: SPI_Interface_Project_Presentation.pptx
4. In GitHub repository, click Add file -> Upload files and upload all files from this folder.
5. Commit and push to main branch. Go to Settings -> Pages -> Branch: main and save.
6. Visit https://<yourusername>.github.io to see the site live.

Notes:
- The site uses Three.js via CDN; it requires internet connection to load the Three.js library.
- The coin uses your logo as face texture. For best results, use a high-resolution square PNG.

// coin.js - creates a realistic-looking coin using Three.js and animates a toss
// IMPORTANT: Place a 'logo.png' file (your provided symbol) into the same folder as these files.
// The coin will use logo.png as the face texture for both sides.

(function(){

  const canvas = document.getElementById('threeCanvas');
  const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.setSize(canvas.clientWidth, canvas.clientHeight, false);

  const scene = new THREE.Scene();

  // Camera
  const fov = 40;
  const aspect = canvas.clientWidth / canvas.clientHeight;
  const camera = new THREE.PerspectiveCamera(fov, aspect, 0.1, 1000);
  camera.position.set(0, 35, 80);

  // Lighting
  const ambient = new THREE.AmbientLight(0xffffff, 0.45);
  scene.add(ambient);
  const dir = new THREE.DirectionalLight(0xffffff, 0.7);
  dir.position.set(50,100,50);
  scene.add(dir);

  // Coin geometry (thin cylinder)
  const coinRadius = 24;
  const coinThickness = 2.8;
  const geometry = new THREE.CylinderGeometry(coinRadius, coinRadius, coinThickness, 64, 1);
  geometry.rotateX(Math.PI/2);

  // Load textures (front/back) from logo.png (same image used) and a simple edge texture
  const loader = new THREE.TextureLoader();
  const logoTex = loader.load('logo.png', ()=>{ renderer.render(scene,camera); });
  logoTex.anisotropy = renderer.capabilities.getMaxAnisotropy();

  // Create metallic material for edge
  const edgeMat = new THREE.MeshStandardMaterial({ color: 0x7a5833, metalness: 0.9, roughness: 0.35 });

  // Create face materials: use logo texture mapped onto circular faces
  const faceMat = new THREE.MeshStandardMaterial({ map: logoTex, metalness: 0.5, roughness: 0.4, side: THREE.DoubleSide });

  // Cylinder has 3 groups: top cap, side, bottom cap. We'll split materials:
  // But easiest approach: create three meshes: side (thin torus-like), front disc, back disc.
  // Side mesh:
  const sideGeo = new THREE.CylinderGeometry(coinRadius+0.1, coinRadius+0.1, coinThickness, 128, 1, true);
  const sideMesh = new THREE.Mesh(sideGeo, edgeMat);
  sideMesh.rotation.x = Math.PI/2;

  // Face meshes (discs)
  const circleGeo = new THREE.CircleGeometry(coinRadius, 64);
  const front = new THREE.Mesh(circleGeo, faceMat);
  const back = new THREE.Mesh(circleGeo, faceMat);
  front.position.set(0, coinThickness/2 + 0.01, 0); front.rotation.x = -Math.PI/2;
  back.position.set(0, -coinThickness/2 - 0.01, 0); back.rotation.x = Math.PI/2;

  const coinGroup = new THREE.Group();
  coinGroup.add(sideMesh); coinGroup.add(front); coinGroup.add(back);
  scene.add(coinGroup);

  // Ground mirror / shadow
  const groundGeo = new THREE.PlaneGeometry(400,400);
  const groundMat = new THREE.ShadowMaterial({ opacity: 0.25 });
  const ground = new THREE.Mesh(groundGeo, new THREE.MeshBasicMaterial({color:0x000000,opacity:0.12,transparent:true}));
  ground.rotation.x = -Math.PI/2; ground.position.y = -50;
  scene.add(ground);

  // Simple camera controls on pointer
  let isPointerDown = false, startX=0, startY=0;
  canvas.addEventListener('pointerdown', (e)=>{ isPointerDown=true; startX=e.clientX; startY=e.clientY; });
  canvas.addEventListener('pointerup', ()=>{ isPointerDown=false; });
  canvas.addEventListener('pointermove', (e)=>{
    if(isPointerDown){
      const dx = (e.clientX - startX) * 0.002;
      const dy = (e.clientY - startY) * 0.002;
      coinGroup.rotation.y += dx;
      coinGroup.rotation.x += dy;
      startX = e.clientX; startY = e.clientY;
    }
  });

  // Resize handling
  function resizeRenderer(){
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (canvas.width !== width || canvas.height !== height) {
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    }
  }
  window.addEventListener('resize', resizeRenderer);

  // Animation variables for toss physics approximation
  let anim = null;
  let tossing = false;

  function tossCoin() {
    if (tossing) return;
    tossing = true;
    // initial state
    coinGroup.position.set(0, 0, 0);
    coinGroup.rotation.set(Math.random()*0.2, Math.random()*0.2, Math.random()*0.2);

    // parameters
    const initialUp = 60 + Math.random()*40; // upward travel
    const duration = 2200 + Math.random()*1200; // ms
    const spin = 12 + Math.random()*14; // spins (revolutions)
    const start = performance.now();

    // random tilt and axis
    const axis = new THREE.Vector3(0.6 - Math.random()*1.2, 0.2 + Math.random()*0.6, 0.6 - Math.random()*1.2).normalize();
    const randomTilt = (Math.random()*0.6 - 0.3);

    function frame(t){
      const el = (t - start) / duration;
      if (el >= 1) {
        // settle: small wobble, then stop
        coinGroup.position.y = 0;
        // Align to heads or tails randomly by rotating X to 0 or PI
        const faceChoice = Math.random() < 0.5 ? 0 : Math.PI;
        // Smoothly rotate to nearest face
        new TWEEN.Tween(coinGroup.rotation)
          .to({ x: faceChoice, y: coinGroup.rotation.y % (Math.PI*2), z: 0 }, 600)
          .easing(TWEEN.Easing.Cubic.Out)
          .start()
          .onComplete(()=>{ tossing=false; });
        anim = null;
        return;
      }

      // vertical motion (parabola-like)
      const up = initialUp * Math.sin(Math.PI * el); // peak at middle
      coinGroup.position.y = up;

      // gravity pull downward + small lateral drift
      coinGroup.position.x = Math.sin(el * Math.PI * 2) * 6 * (1-el);
      coinGroup.position.z = Math.cos(el * Math.PI * 2) * 6 * (1-el);

      // spin rotation around axis
      const totalSpin = spin * Math.PI * 2 * el;
      // apply quaternion rotation around axis plus a tiny precession
      const q = new THREE.Quaternion().setFromAxisAngle(axis, totalSpin);
      coinGroup.quaternion.slerp(q, 0.9);

      // small wobble
      coinGroup.rotation.z = Math.sin(el * Math.PI * spin) * 0.4 * (1-el);

      anim = requestAnimationFrame(frame);
    }

    anim = requestAnimationFrame(frame);
  }

  // Use simple tween library for final easing (include small inline TWEEN)
  // Minimal TWEEN implementation (only used for final settle tween)
  window.TWEEN = window.TWEEN || { _tweens:[] };
  (function(){
    function Tween(obj){ this.obj = obj; this.props = {}; this.toProps = {}; this.time = 0; this.dur=500; this.easing=(t)=>t; this.onComplete=null; }
    Tween.prototype.to = function(target, dur){ this.toProps=target; this.dur=dur||500; return this; };
    Tween.prototype.easing = function(fn){ this.easing=fn; return this; };
    Tween.prototype.start = function(){ this.time = performance.now(); TWEEN._tweens.push(this); };
    Tween.prototype.onCompleteCb = function(cb){ this.onComplete = cb; return this; };
    Tween.prototype.update = function(now){
      const t = Math.min(1,(now - this.time)/this.dur); const tt = this.easing(t);
      for(const k in this.toProps) this.obj[k] = this.obj[k] + (this.toProps[k]-this.obj[k]) * tt;
      if(t>=1){ if(this.onComplete) this.onComplete(); return true; } return false;
    };
    TWEEN.Tween = Tween;
    TWEEN.Easing = { Cubic:{ Out:function(t){ return 1-Math.pow(1-t,3);} } };
    // runner
    function run(now){
      requestAnimationFrame(run);
      const list = TWEEN._tweens.slice();
      for(let i=list.length-1;i>=0;i--){ if(list[i].update(now)) TWEEN._tweens.splice(i,1); }
    }
    run(performance.now());
  })();

  // Basic render loop
  function renderLoop(){
    resizeRenderer();
    // slow idle rotation
    coinGroup.rotation.y += 0.002;
    TWEEN && TWEEN._tweens && TWEEN._tweens.length && TWEEN._tweens;
    renderer.render(scene, camera);
    requestAnimationFrame(renderLoop);
  }
  renderLoop();

  // Button and pointer interaction
  const tossBtn = document.getElementById('tossBtn');
  tossBtn.addEventListener('click', tossCoin);
  // Also tap coin
  canvas.addEventListener('click', tossCoin);

  // show year in footer
  document.getElementById('year').innerText = new Date().getFullYear();

})();